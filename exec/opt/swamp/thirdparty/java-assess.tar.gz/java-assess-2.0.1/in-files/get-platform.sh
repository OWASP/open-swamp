#!/bin/bash

function get_machine_type(){
    #print the machine hardware name
    echo $(uname --machine)
}

function get_platform(){
    RedhatRelease='/etc/redhat-release'
    DebianRelease='/etc/debian_version'

    if test -f ${RedhatRelease}; then
	if grep --quiet -E '((^Red Hat Enterprise Linux Server release [0-9.]+ \([^)]+\))|(^Scientific Linux release [0-9.]+ \([^)]+\)))' ${RedhatRelease}; then
	    mach_type=$(get_machine_type)
	    if test ${mach_type} == "x86_64"; then
		bits="64"
	    elif test ${mach_type} == "i686"; then
		bits="32"
	    else
		echo "unknown architecture"
		exit 1
	    fi
	    
	    if grep --quiet -E '^Red Hat Enterprise Linux Server release [0-9.]+ \([^)]+\)' ${RedhatRelease}; then
		version=$(sed -n -E 's:^Red Hat Enterprise Linux Server release ([0-9.]+) \([^)]+\):\1:p' ${RedhatRelease})
		platform="rhel"
	    else
		version=$(cat ${RedhatRelease} | awk '{ print $4}')
		platform="scientific"
	    fi
	    sys_type="${platform}-${version}-${bits}"
	elif grep --quiet -E '^Fedora release 18' ${RedhatRelease}; then
	    sys_type="fedora-18.0-64";
	elif grep --quiet -E '^Fedora release 19' ${RedhatRelease}; then
            sys_type="fedora-19.0-64";
	fi

	echo ${sys_type}
    elif test -f ${DebianRelease}; then
	if grep --quiet '7.1' ${DebianRelease}; then
	    sys_type='debian-7.0-64'
	elif grep --quiet 'wheezy/sid' ${DebianRelease}; then
	    sys_type='ubuntu-12.04-64'
	    if test -d '/opt/swamp/android'; then
		sys_type="android-$sys_type"
	    fi
	else
	    echo "unknown Debain Release"
	    exit 1
	fi
	echo ${sys_type}
    else
	echo "Unknown Platform"
	exit 1
    fi
}

get_platform
