#!/usr/bin/env python

import sys
import os
import os.path as osp
import shlex
import subprocess

from confreader import read_conf_into_dict

def array_get(array, idx, default):
    try:
        return array[idx]
    except IndexError:
        return default

def main(pkg_conf):
    '''Reads config-cmd, config-opt, config-dir from package.conf
    and runs the config-cmd
    '''

    if 'config-cmd' not in pkg_conf:
        return 2

    config_dir = os.getcwd()

    if 'config-dir' in pkg_conf:
        config_dir = osp.join(config_dir, pkg_conf['config-dir'])

    cmd = shlex.split(' '.join([pkg_conf['config-cmd'],
                                pkg_conf.get('config-opt', '')]))

    print(cmd)
    print(config_dir)

    try:
        subprocess.Popen(cmd,
                         stdin=None,
                         stdout=sys.stdout,
                         stderr=sys.stderr,
                         cwd=config_dir)
    except subprocess.CalledProcessError as err:
        print(err)
        return 1

    return 0

if __name__ == "__main__":
    pkg_conf_path = array_get(sys.argv, 1, 'package.conf')
    sys.exit(main(read_conf_into_dict(pkg_conf_path)))

